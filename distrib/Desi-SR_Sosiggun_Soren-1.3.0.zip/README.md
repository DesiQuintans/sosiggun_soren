# SR Sosiggun Soren 1.3.0

Whenever I got bad weapon drops in SupplyRaid, I would pick up and use the enemies' sosigguns. It sometimes felt like cheating, especially if they had decent sights and higher power than I was supposed to have, so I decided to make a SupplyRaid character where using sosigguns *isn't* cheating. 

Sosiggun Soren is a character for the [SupplyRaid](https://h3vr.thunderstore.io/package/Packer/SupplyRaid/) game mode, balanced for use with [SafehouseProgression](https://h3vr.thunderstore.io/package/NGA/SafehouseProgression/). Soren's playstyle is built around being low on ammo for your regular guns; you'll need to conserve ammo by grabbing and using sosigguns where possible. If you're lucky, a sosig might drop the real version of a sosiggun for you to bring home -- there are 57 guns, 6 melee weapons, and 5 super-rare guns to collect.

Soren's difficulty depends heavily on the characteristics of the enemy faction you're playing against, namely: The armour and weaponry of the sosigs; their respawn rate; and the number that can be on the field at the same time. Soren comes with a custom faction, the Slow Burners, that gives a gentler difficulty curve and longer respawn times so that you have more time to scrounge for sosigguns.



# Play tips

- I suggest setting Spawnlock Enabled for Soren, but **not** spawnlocking ammo. There are two reasons for this:
	1. With Spawnlock Enabled, you can reload empty sosigguns by shaking them. You'll hear a rattling brass sound while you're shaking, and a *Ding!* when the sosiggun is reloaded. Only fully empty sosigguns can be reloaded. Most sosigguns have an open-looking chamber when they are emptied.
	2. There is an engine bug where, if Limited Ammo mode is enabled, then revolvers and internal magazine shotguns spawn into the world with a bunch of loose ammo or speedloaders. It all works fine with Spawnlock Enabled though.

- A grappling hook, range finder, and flashlight are free at supply points if you need them for the map you're in.

- Stun grenades and smoke grenades are free at every supply point. Use stuns to disable approaching sosigs. Use smokes to obstruct bad sightlines, especially when you're outranged.

- Some ammo boxes are sold in the Melee section of the shop, for use with guns that need to be loaded with individual cartridges (shotguns, revolvers, bolt-actions).

- Looted weapons come with the bare minimum, e.g. a shotgun drops with a box of 5 shells. Weapons that you purchase from the Buy Panel come with significantly more ammo, and sometimes other attachments.

- If you put lots of empty magazines and speedloaders on the Ammo Refill table (even ammo boxes!) you can refill everything with a single purchase.



# Known issues

- *Unwanted ammo spawns in Limited Ammo mode.* There is an engine bug where, if Limited Ammo mode is enabled, then revolvers and internal magazine shotguns spawn into the world with a bunch of loose ammo or speedloaders. I have reported this bug.
- *Most sosigguns cannot be extracted to the safehouse or saved.* More sosigguns are removed from you when you extract to the safehouse, or are not saved when you leave the safehouse. Some sosigguns *are*, like the P90 and DP12. I have reported this bug.
- *Sometimes double attachments spawn from the Buy Panel.* I have made some weapons spawn with bespoke attachments when purchased through the Buy Panel, e.g. the Ruger 10/22 spawns with its bespoke Picatinny rail adapter. Because H3VR randomly chooses to do this on its own sometimes, you may get two copies of the attachment.
- *There may be issues with saving ammo boxes in gun cases.* According to someone on the H3VR discord, some ammo boxes create issues with H3VR's scene saving. For safest results you should only put guns, magazines, and health items inside cases.



# Future wishlist

- When SupplyRaid supports per-level drop chances, I'd like to have higher-tier weapons drop only in later levels. For now, weapons are in tiered loot tables that get much rarer as the tier improves.



# Recommended mods

- [PackersVendingMachines](https://h3vr.thunderstore.io/package/Packer/Packers_Vending_Machines/) lets you put ammo and ordnance vending machines in your safehouse. Emphasises preparation before raids. All guns in Soren's pool have an ammo box.
- [HardcoreSosigAI](https://h3vr.thunderstore.io/package/NGA/HardcoreSosigAI/) speeds up sosigs' reaction times. This character and its faction, the Slow Burners, were balanced with this mod in mind.
- [BulletKinesis](https://h3vr.thunderstore.io/package/OsaPL/BulletKinesis/) attracts nearby bullets to your hand when you grab one with the laser grabber.
- [PlayerFootsteps](https://h3vr.thunderstore.io/package/Kodeman/PlayerFootsteps/) lets sosigs hear you when you're running nearby (or not hear you when you're walking slowly).



# Changelog

## 1.3.0 (2024-01-13)

- Disabled the ammo refill tables during raids 🙈. This incentivises:
	1. Preparation at the safe house. Buy ammo boxes from [PackersVendingMachines](https://h3vr.thunderstore.io/package/Packer/Packers_Vending_Machines/), bring it to raids with you.
	2. Upgrading to larger magazines so that you enter raids with more ammo.
	3. Choosing to use sosigguns and looted guns to save your good ammo.
- Removed minigun from the MG shop pool. It is still a super-rare drop.
- Increased loot drop chances by an average of 0.05 percentage points (i.e. 1.50% increased to 1.55%).
- Reordered shop items so that shotguns are now cheaper than repeating pistols.
- Increased shop cost of weapons by 0-2 tokens. This puts weapon costs in the same ballpark as Extraction Eddie: Eddie's IQR for weapon costs is [8, 19] and Soren's is [7, 14].
- Increased token reward after at Level 5/Endless to 4 tokens (from 3).


## 1.2.0 (2024-01-12)

- Added [GunCaseFix](https://h3vr.thunderstore.io/package/NGA/GunCaseFix/) as a dependency since I now have gun cases in here.
- Added [StandardManufacturing DP12](https://h3vr.thunderstore.io/package/cityrobo/StandardManufacturing_DP12/) as a dependency.
	- Out of the handful of sosigguns that do not have real counterparts in the game (DP12, M1917 Browning, M2 Flamethrower, SIG M17, ASh-12, MCX Rattler, FN2000, Mk14 EBR, Mk47 Mutant, XM7, PKM, XM250), I felt like the DP12 was the only one that operated fundamentally differently, and so couldn't simply be replaced with a different existing gun.
- Replaced VT13 Shorty with DP12 in shop and loot tables.
- Moved VT13 Shorty to the super-rare drop table (it doesn't have an associated sosiggun, it just reminds me of the 870 sosiggun but as a semi-auto).
- Added rail adapter to purchased Mini-14.


## 1.1.0 (2024-01-11)

- Added a saveable gun case to the Tools shop. It costs 4 tokens, double what a backpack costs, because you can fit a lot more stuff in it.
- Removed `Sosiggun_LeverAction` from starting long guns pool (not enough ammo).
- Removed `Sosiggun_PSG1` from starting long guns pool (too hard to aim with massive unusable scope in the way).
- Removed free bayonet from looted Mosin 91/30.
- Replaced the shield (`Shield_RiotShield`, without viewing window) with `Shield_BallisticShield` (with a viewing window) to match the sosigs' shields.
- Removed the shield from the Melee weapons shop pool. 
- Added the shield as its own category to the Melee weapons shop pool (costs 4 tokens).
- Replaced S9R derringer (.32 ACP) with Model 6 (.357 Magnum). The S9R had so little stopping power that it was not even worth firing it.
	- When looted, the Model 6 drops a box of JHP ammo (other .357 revolvers drop FMJ).
	- If purchased, the Model 6 also gives a consolation prize of a .357 speedloader. The derringer can't use it, but the other revolvers can.
- Removed `BayonetGrillFork` and `BayonetSpatula` from the bayonet attachment pool.
- Allowed all melee weapons (except ballistic shield) to spawn as a starting item. 
	- Previously, the Tanto was always the starting melee item. Longer weapons were regarded as upgrades, and so had to be purchased.
	- Melee weapons are not (and were never) in any loot drop tables.


## 1.0.0 (2024-01-10)

- Initial release.

