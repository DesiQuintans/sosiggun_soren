# SR Sosiggun Soren Changelog

## 1.0.0 (2024-01-10)

- Initial release.

